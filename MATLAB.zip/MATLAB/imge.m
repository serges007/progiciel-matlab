function gb(obj,event)
% Fonction associ�e au Callback de l'objet Pushbutton
% obj : identifiant de l'objet Pushbutton
% event : �v�nement li�s � l'objet Pushbutton
X=imread('logo1.jpg');
ax=axes('position',[0.4 0.8 0.2 0.2]);
imagesc('cdata',X);
uistack(ax,'bottom');
