function p=script2(n)
clc
format long
p = sqrt(n);
end