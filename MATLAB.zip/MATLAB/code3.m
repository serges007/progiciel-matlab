a = sqrt(3)
b = sqrt(3)