function script21(  )
clc
f= [4 3 -1 4];
g= [2 0 3 5 -1];

conv(f,g)
end

