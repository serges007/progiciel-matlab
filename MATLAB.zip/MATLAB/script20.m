function  script20( m )
clf;
%fig = figure()
x = [-1:m:1] % 
f = exp(x)-2*cos(x) %
figure(1);
 plot(x,f,'-') % tracer de la courbe
title('resolution d''equation non lineaire') % titre de la figure
grid on 
%xlabel('x')
%ylabel('f(x)')
%clear all
clc
x(1) = input('entrer la valeur de x(1): \n');
e = 1e-10;
n = 5000;
for  i =2:n
    f = exp(x(i-1))-2*cos(x(i-1));
    diff = exp(x(i-1)) + 2*sin(x(i-1));
    x(i) = x(i-1) - f/diff;
        if abs(x(i)-x(i-1))<= e
            xp = x(i);
            fprintf('xp = %f\n', x(i));
            break;
        end
end
j = 1:i;
figure(2);
plot(j,x(j),'*r',j,x(j))
xlabel('nombre d''it�ration');
title('convergence de la solution: m�thode de newton');
disp('les valeurs succ�ssive de x(i) sont : ');
x'
end

