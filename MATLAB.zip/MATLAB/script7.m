function xn =script7(n)
 clc
 x =1
 while x>0
     xn = x
     x = x/2
 end
 xn
end