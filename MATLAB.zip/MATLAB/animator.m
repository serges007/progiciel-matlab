function animator(action)
switch(action)
  case 'load',
    load mydata;
    set(gcbf,'UserData',XYData)
    LocalPlotFcn
  case 'plot'
    LocalPlotFcn
  case 'close'
    close(gcbf)
end
function LocalPlotFcn
% This is a subfunction
XYData=get(gcbf,'UserData')
x=XYData(:,1);
y=XYData(:,2);
plot(x,y)
end