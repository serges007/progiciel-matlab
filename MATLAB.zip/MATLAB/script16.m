function  script16( n)
clc
fig = figure()
 x = 1;
 pas = 10.^(-[1:n]);
 Dn = (sin(x + pas) - sin(x))./pas
 Er = abs(Dn -cos(x))
 loglog(pas,Er)
 
end
