function p=facto2(n)
p=n;
while n>1
    n=n-1;
    p=p*n;
end
end