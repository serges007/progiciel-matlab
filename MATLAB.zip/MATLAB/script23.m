function script23(  )
clc
p = [1 2 -7 -8 12];
roots(p)
end

