clc
A = [3 2 -2;-1 0 1; 1 1 0]
det = det(A)
rank = rank(A)
inv = inv(A)
val_prop = eig(A)