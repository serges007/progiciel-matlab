function x3 = mesh(x1,x2)
x3 = x1.*exp(-x1.^2-x2.^2);
end

