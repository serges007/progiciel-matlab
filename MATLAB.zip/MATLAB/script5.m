function s =script5(n)
 clc
 x =0
 s= 1
 terme = 1
 for k=1:n
     terme = (x*terme)/k;
     s = s + terme;
 end
 s = exp(10)
end