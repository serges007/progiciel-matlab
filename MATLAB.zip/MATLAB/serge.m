x = [-1:0,1:11];
p = exp(x);
z = 10*cos(3*x);
t = -3*x;
y = p + z + t;
plot(x,y,'b-')
