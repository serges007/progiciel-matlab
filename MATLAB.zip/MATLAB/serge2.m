function [ result ] = Untitled2( a,b,c)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

 a = input('entrer la valeur de a :');
 b = input('entrer la valeur de b:');
 c = input('enter la valeur de c');
 if(isempty(a) | a == 0)
    x = -c/b;
    disp(x)
  else
    delta = b^2 -4*a*c;
    x1 = (-b - sqrt(delta))/2*a;
    x2 = (-b + sqrt(delta))/2*a; 
    disp(x1)
    disp(x2)
 end

end

