clc
b = rand(3,3)
c = max(b);
d = max(max(b));
b
c
d
sort(c)
sort(b)