%cr�ation de la fonction TP1
function manipulation
handles(1)=figure('units','pixels','position',[250 250 450 450],'color',[0.225 0.213 0.387],'numbertitle','off','name','Bienvenue aux differents manipulations du TP1 ','menubar','none','tag','interface');
handles(2)=uicontrol('style','pushbutton','units','normalized','position',[0.1 0.08 0.1 0.05],'ForegroundColor',[0.999 0.113 0.287],'BackgroundColor',[0.922 0.222 0.055],'string','program','callback','program');
handles(3)=uicontrol('style','pushbutton','units','normalized','position',[0.21 0.08 0.1 0.05],'ForegroundColor',[0.000 0.777 0.111],'BackgroundColor',[0.966 0.555 0.822],'string','manip1','callback','code1');
handles(4)=uicontrol('style','pushbutton','units','normalized','position',[0.32 0.08 0.1 0.05],'ForegroundColor',[0.000 0.777 0.111],'BackgroundColor',[0.966 0.555 0.822],'string','manip2','callback','manip2');
handles(5)=uicontrol('style' , 'text' ,'units','normalized','position' , [0.2,0.7,0.6,0.19],'BackgroundColor',[0.225 0.213 0.387],'ForegroundColor',[0.999 0.999 0.999],'string' , 'Les diff�rents manipulations du TP1' , 'fontsize' , 20 );
handles(5)=uicontrol('style' , 'text' ,'units','normalized','position' , [0.2,0.45,0.6,0.19],'BackgroundColor',[0.225 0.213 0.387],'ForegroundColor',[0.999 0.999 0.999],'string' , 'Pr�sentation: Juslin Arnaud KOMNANG' , 'fontsize' , 12 );
handles(5)=uicontrol('style' , 'text' ,'units','normalized','position' , [0.2,0.25,0.6,0.19],'BackgroundColor',[0.225 0.213 0.387],'ForegroundColor',[0.999 0.999 0.999],'string' , 'Supervision: Mr. Pie D�sir� EBODE ' , 'fontsize' , 12 );
handles(6)=uicontrol('style','pushbutton','units','normalized','position',[0.43 0.08 0.1 0.05],'ForegroundColor',[0.000 0.777 0.111],'BackgroundColor',[0.966 0.555 0.822],'string','manip3','callback','code1');
handles(7)=uicontrol('style','pushbutton','units','normalized','position',[0.54 0.08 0.1 0.05],'ForegroundColor',[0.000 0.777 0.111],'BackgroundColor',[0.966 0.555 0.822],'string','manip4','callback','manip4');
