function p =script4(n)
clc
p = det(rand(n)) 
end