function p =script04(n)
clc
p = inv(rand(n)) 
end