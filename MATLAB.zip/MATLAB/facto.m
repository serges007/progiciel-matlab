function p=facto()
clc
n=input('entrer un entier naturel : ');
%Affiche un menu optionnel
result=menu('figure(Quelle methode voulez vous utiliser?)','facto0','facto1','facto2')
%le choix etant op�rer on apelle la fonction correspondante
if result==1
   p =  facto0(n)
elseif result==2
    p = facto1(n)
else p=  facto2(n)
    
end

end