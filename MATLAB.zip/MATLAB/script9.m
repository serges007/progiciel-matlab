function script9(n)
clc
 b = rand(3,3);
 c = max(b);
 d = max(max(b));
 disp('b = rand(n,n) :') 
 disp(b)
 disp('c = max(b) :')
 disp(c)
 disp('d = max(max(b)) :')
 disp(d)
 sort(c)
 sort(b)

end