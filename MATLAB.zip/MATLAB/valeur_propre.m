function m = valeur_propre(a)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
m = eig(a)

end

