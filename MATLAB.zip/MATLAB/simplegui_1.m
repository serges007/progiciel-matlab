function simplegui_1()

%% Beginning 
% Create figure
clear all
close all hidden
clc

imageArray = [];    

score = [];

f = figure('Visible','off','Name','simplegui_1',...
    'Position',[520,100,1300,700]);

% Create an axes object 
Img1 = axes('Parent',f,'Units','pixels',...
    'Position',[38 152 512 512]);
Img2 = axes('Parent',f,'Units','pixels',...
    'Position',[750 152 512 512]);

% Create a slider to display the images
hslider = uicontrol('Style', 'slider',...
    'Parent', f, 'String', 'Image No.',...
    'Position', [100 115 350 20]);

% % create a static text to ask for image folder
hloadimages = uicontrol('Style','text',...
    'String','Load Images','Position',[600 615 100 20]);

% create a pushbutton to ask for image folder
hSelectFolder1 = uicontrol('Style','pushbutton',...
    'String','Select Folder','Position',[570 550 150 50]);

% create a pushbutton to select reference image (highest dose)
hSelectFolder2 = uicontrol('Style','pushbutton',...
    'String','Reference Image',...
    'Position',[950 100 200 35]);

% % create a static text to show log messages
htext = uicontrol('Style','text',...
    'String','Log message','Position',[560 75 150 20]);

% % create display messages for log files 
hlog = uicontrol('Style','edit',...
    'Position',[100 18 1070 50],...
    'BackgroundColor','w',...
    'HorizontalAlign','left');


set(hSelectFolder1, 'Callback', {@SelectFolderbutton_callback});
set(hSelectFolder2, 'Callback', {@SelectRefImage_callback});
set(hslider, 'Callback', {@slider_callback});
set(hlog, 'Callback', {@Log_callback});

set([f,hloadimages,hSelectFolder1,hSelectFolder2,hlog,htext,hslider],...
    'Units','normalized');

set(f, 'Visible', 'on'); % show GUI now!
movegui(Img1,'onscreen')% To display application on screen
movegui(Img1,'center') % To display application in the center screen


function SelectFolderbutton_callback(source, eventdata)
    % Obtain directory or folder containing images 
    myFolder = uigetdir();
    % Show error message if folder inexistent
    if ~isdir(myFolder)
        errorMessage = sprintf('Error: The following folder does not exist:\n%s', myFolder);
        uiwait(warndlg(errorMessage));
        return;
    end

    % access image files (DICOM or IMA files)
    filePattern = fullfile(myFolder, '*.dcm');
    dcmFiles = dir(filePattern);
    baseFilenames = {dcmFiles.name};
    numberOfFiles = length(baseFilenames);
    randomOrder = [randperm(numberOfFiles)];
    for k = 1:numberOfFiles
        filenumber = randomOrder(k);
        fullFileName = fullfile(myFolder, baseFilenames{filenumber});
        fprintf(1, 'Now reading %s\n', baseFilenames{filenumber});
        message = sprintf('Now reading %s', baseFilenames{filenumber});
        imageArray(:,:,k) = dicomread(fullFileName);
    end

    sliderMin = 1; % first image file
    sliderMax = numberOfFiles; % last image file
    sliderStep = [1, 1]/(sliderMax - sliderMin); % major and minor steps of 1

    set(hslider, 'Min', sliderMin);
    set(hslider, 'Max', sliderMax);
    set(hslider, 'SliderStep', sliderStep);
    set(hslider, 'Value', sliderMin); %   set to beginning of sequence

    axes(Img1); 
    imagesc(imageArray(:,:,1), [1000 1150]);
    colormap(gray);

    axes(Img2); 
    imagesc(imageArray(:,:,13), [1000 1150]);
    colormap(gray);

    set(hlog, 'String', message,'Min',1,'Max',numberOfFiles);

end

%% Beginning of slider callback function
function slider_callback(source, eventdata)
    currentSlice = get(source, 'Value');
    axes(Img1); 
    imagesc(imageArray(:,:,currentSlice), [1000 1150]);
    colormap(gray); axis image; impixelinfo;
    disp(['Slider moved to ' num2str(currentSlice)]);
    message2 = sprintf('How many contrast targets are visible for %s?\n', num2str(currentSlice));
    score(currentSlice) = str2double(input(message2, 's'));
    while score(currentSlice) > 9 || score(currentSlice) < 0 || isnan(score(currentSlice));
        errorMessage = sprintf('Score invalid!\nPlease re-enter score (0 - 9)!');
        uiwait(warndlg(errorMessage));
        score(currentSlice) = str2double(input(message2, 's'));
    end
    %assignin('base',score(currentSlice),score)
end

 %% Beginning of log callback function
function Log_callback(source,eventdata)
     newmsg = get(source, 'String');
     set(hlog, 'String', newmsg);
     sprintf('Now reading %s', newmsg);

end

 %% Beginning of RefImage callback function
function SelectRefImage_callback(source, eventdata)
    %FileName = uigetfile('*.dcm', 'Pick a reference DICOM file');
    %refImage = dicomread(FileName);
    axes(Img2);
    imagesc(refImage, [1000 1150]); 
    colormap(gray); impixelinfo;
end

end