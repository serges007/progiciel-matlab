clc
x =0
n = 5
s = 1
terme = 1
for k = 1:n ,terme = x*terme/k;
    s = s + terme;
end
s = exp(10)
    