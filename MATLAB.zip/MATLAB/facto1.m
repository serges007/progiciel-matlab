function p=facto1(n)
if or(n==0,n==1)
    p=1;
else
    p=n*facto1(n-1);
end