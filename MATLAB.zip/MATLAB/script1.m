function p=script1(n)
clc
p = 5*n;
end