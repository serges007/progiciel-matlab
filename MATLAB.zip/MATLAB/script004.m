function p =script004(n)
clc
p = rank(rand(n)) 
end