function  script11(n)
clc
fig = figure()
x = [0:n:2*pi]
y = cos(3*x)
plot(x,y)
end