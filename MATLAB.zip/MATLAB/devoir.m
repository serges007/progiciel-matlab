disp('*****************DEVOIR DE KENGNE MAFOTSING INES*****************');
disp(' ');
a = 2; Xn = 1;%Xn est initialise � 1
disp('    n                  Xn   ,           En = Xn - sqrt(2)')
format long
for n = 1:29
    Xn = 1/3*(2*Xn + a/Xn); En = Xn - sqrt(2);
    u = [n,Xn,En];
    disp(u);
end
    