function  script14( n)
clc
fig = figure()
[X,Y] = meshgrid(-2:n:2, -2:n:2);
Z = X.*exp(-X.^2-Y.^2);
contour(X,Y,Z)
contour(X,Y,Z)

end