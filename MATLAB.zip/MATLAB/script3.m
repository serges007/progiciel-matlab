function p =script3(n)
clc
p  = rand(3)

end