function  interface( )
fig1 = figure;
[uicontrol('Style','pushbutton','String','iteration','Callback','','Units','point','position',[50 65 75 35]); uicontrol('Style','pushbutton','String','Plot','Callback','iteration(29)','Units','point','position',[50 150 75 35]);uicontrol('Style','pushbutton','String','Accueil','Callback','','Units','point','position',[50 225 75 35])]

end

