clc
theta = pi*[-4:0.04:4];
r = linspace(1.6,201);
x = r.*(1 + cos(theta));
y = r.*sin(theta);
z = r;
plot3(x,y,z,'k*')
grid