function iteration( n )

disp('');
%X0 = 1;

format long
Xi = 1;
 disp('       n               Xn                    en')
for i = 1:n
    Xi = 1/3*(2*Xi + 2/Xi);
    ei = Xi - sqrt(2);
    A=[i,Xi,ei];
   
    disp(A)
end

