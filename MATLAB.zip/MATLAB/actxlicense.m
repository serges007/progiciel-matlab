function lic = actxlicense(progid)

if strcmpi(progid, 'AIR.AirCtrl.1')
lic = 'Copyright (c) 1996 ';
return;
end

if strcmpi(progid, 'MSComctlLib.Toolbar.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComctlLib.SBarCtrl.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComctlLib.TabStrip.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComctlLib.TreeCtrl.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComCtl2.UpDown.2')
lic = '651A8940-87C5-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComctlLib.Slider.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'RICHTEXT.RichtextCtrl.1')
lic = ' qhj ZtuQha;jdfn[iaetr ';
return;
end

if strcmpi(progid, 'MSComCtl2.Animation.2')
lic = '651A8940-87C5-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComCtl2.DTPicker.2')
lic = '651A8940-87C5-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComCtl2.FlatScrollBar.2')
lic = '651A8940-87C5-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComctlLib.ImageComboCtl.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComctlLib.ImageListCtrl.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'InfoPath.Editor.3')
lic = 'InfoPath.Editor';
return;
end

if strcmpi(progid, 'MSComctlLib.ListViewCtrl.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComCtl2.MonthView.2')
lic = '651A8940-87C5-11d1-8BE3-0000F8754DA1';
return;
end

if strcmpi(progid, 'MSComctlLib.ProgCtrl.2')
lic = '9368265E-85FE-11d1-8BE3-0000F8754DA1';
return;
end
