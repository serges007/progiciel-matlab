x = 1;
pas = 10.^(-[1:16]);
Dn = (sin(x + pas) - sin(x))./pas;
Er = abs(Dn-cos(x));
loglog( pas, Er);
