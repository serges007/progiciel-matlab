function   script19( n )
clc
figure()
x = [0:n];
y = sin(x);
xi = [0 : .25 : 10];
yi = interp1(x,y,xi,'cubic');
plot(x,y,'o',xi,yi)
title('courbe d''interpolation')
end

