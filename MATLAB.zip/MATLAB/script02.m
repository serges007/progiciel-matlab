function p =script02(n)
clc
format short
p = sqrt(n);
end