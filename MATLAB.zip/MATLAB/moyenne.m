function m = moyenne(n = input('entrer la valeur de n:   '))
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
%n = input('entrer la valeur de n:   ');
A = rand(n);
imagesc(A);
axis equal off;
disp('la moyenne est : ');
m = mean(mean(A));
end

