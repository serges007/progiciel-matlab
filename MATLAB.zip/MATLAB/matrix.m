function  Untitled( mat )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
P = zeros(3,3)
fprintf('');
B = det(P);
A = inv(P);
fprintf('',B)
fprintf('',B)


end

