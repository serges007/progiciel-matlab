function x3 = g(x1,x2)
x3 = x1.*exp(-x1.^2-x2.^2);
end