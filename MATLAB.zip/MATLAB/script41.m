function script41(n)
clc
a = [1 2 3;4 5 6;7 8 10]
b = [n n n]'
x = 2*a;
y = a + [b,b,b];
z = a*b;
A = a.*2;
B =a./2;
C = a.^2;

disp('2*a = ')
disp(x)

disp('a + [b,b,b] = ')
disp(y)

disp('a*b ')
disp(z)

disp('a.*2, a./2, a.^2,a.*b'' = ')
disp(A)
disp(B)
disp(C)


end