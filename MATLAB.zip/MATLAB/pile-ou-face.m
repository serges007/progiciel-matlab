p = 0.5;
u = rand;
if u<p
    disp('pile')
else 
    disp('face')
    
 end