function p=code1(n)
clc
p = 5*n;
end