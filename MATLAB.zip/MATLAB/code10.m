clc
x = [0: 0.01:2*pi]
y = cos(3*x)
p = plot(x,y)