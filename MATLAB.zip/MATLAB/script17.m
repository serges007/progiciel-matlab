function  script17( n)
clc
fig = figure()
 A = rand(n)
 imagesc(A);
 axis equal off
  mean(mean(A))
end
