function  script12(n)
clc
 [X,Y] = meshgrid(-2:n:2, -2:n:2); 
 Z = (X-1).^2 + 10*(X.^2-Y).^2; 
 [C,h] = contour(X,Y,Z,30);
 clabel(C,h,'manual')  

end