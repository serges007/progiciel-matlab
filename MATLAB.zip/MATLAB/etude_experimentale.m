%*************************************************************************
%*****************la g�n�ration des donn�es experimentales****************
%*          y = 1/(1+exp(-x)) + 0,05*rand(1,length(x))                   *
%*************************************************************************

clc; %effacer l'ecran
clear off %effacer les variable de l'espace de travail
x = [-5:0.1:5];%definition de l'intervalle de calcule de signo�de
%fonction signo�de bruit�
y = 1./(1+exp(-x)) + 0.05*rand(1,length(x));
plot(x,y)%tracer de signo�de bruit�
title('fonction signo�de bruit� - polynome d''interpolation');
xlabel('x');
ylabel('y');
% polynome d'interpolation de degre d'ordre 1
p = polyfit(x,y,1);
%valeur du polynome d'interpolation
vp = polyval(p,x);
%tracer du polynome d'interpolation
hold on;
plot(x,vp,'--');
%calcul de l'erreur d'interpolation
erreur = y - vp;
%tracer de la courbe de l'erreur
plot(x,erreur,':');
grid
gtext('Mesures')
gtext('erreur')
gtext('modele')
hold off
%affichage du polynome d'interpolation
disp('polynome d''inpolation',p);
%p
var_erreur = num2str(std(erreur).^2);
disp(['la variance de l''erreur d''interpolation est : ',var_erreur])
