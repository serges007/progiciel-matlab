clc
x = 3
y = x^5
y = x