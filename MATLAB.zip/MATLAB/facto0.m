function p=facto0(n)
p = 2^n;
end