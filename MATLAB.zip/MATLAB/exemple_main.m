function exemple_main
%EXEMPLE_MAIN Exemple d'une interface graphique cod�e � la main

% Cr�ation de l'objet Figure
fig = figure('units', 'pixels', ...
    'position', [520 380 300 200], ...
    'name', 'example_main');

% Cr�ation de l'objet Uicontrol Pushbutton
uicontrol('style', 'pushbutton', ...
    'units', 'pixels', ...
    'position',[75 10 150 20], ...
    'callback', @cb);

% Cr�ation de l'objet Axes
axes('units', 'pixels', ...
    'position', [300 40 1200 750], ...
    'tag','axes1');

% Stockage des identifiants utiles
handles = guihandles(fig);
guidata(fig,handles)

function cb(obj,event)
% Fonction associ�e au Callback de l'objet Pushbutton
% obj : identifiant de l'objet Pushbutton
% event : �v�nement li�s � l'objet Pushbutton

% R�cup�ration des identifiants utiles
fig = get(obj,'parent');
handles = guidata(fig);

% Modification de la couleur de l'objet Axes
set(handles.axes1, 'color', rand(1,3));