n = 31;
theta = pi*[-n:2:n]/n;
r = linspace(0,12,n);
x = r*(1 +cos(theta));
y = r*sin(theta)
z = r*ones(size(theta));
surf(x,y,z)